/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.
Case1: Insertion at beginning

Case2: Insertion at End

Case 3:Insertion at Specific position

Case4: Deletion from beginning

Case5: Deletion from End

Case 6:Deletion from a specific position

Case7: Find the length of a linked list

Case 8: Reverse the Linked list

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
struct node
{
  struct node *prev;
  int data;
  struct node *next;

};

int
main ()
{
  int n, i, a;
  printf ("enter no of elements");
  scanf ("%d", &n);
  struct node *head = NULL, *temp = NULL;
  for (i = 0; i < n; i++)
    {
      scanf ("%d", &a);
      struct node *first = (struct node *) malloc (sizeof (struct node));
      if (head == NULL)
	{
	  first->prev = NULL;
	  first->data = a;
	  first->next = NULL;
	  head = first;
	  temp = first;
	}
      else
	{
	  first->data = a;
	  first->next = NULL;
	  first->prev = temp;
	  temp->next = first;
	  temp = first;
	}

    }
  struct node *ptr = (struct node *) malloc (sizeof (struct node));
  ptr = head;
  int count = 0;
  while (ptr != NULL)
    {
      count++;
      printf ("%d", ptr->data);
      ptr = ptr->next;
    }
  int x, b, z;
  printf
    ("Case1: Insertion at begining\nCase2: Insertion at End\nCase 3:Insertion at Specific position\nCase4: Deletion from beginning\nCase5: Deletion from End\nCase 6:Deletion from a specific position\nCase7: Find the length of a linked list\nCase 8: Reverse the Linked list");
  scanf ("%d", &x);
  switch (x)
    {
    case 1:
      {
	printf ("enter a number to insert");
	scanf ("%d", &b);
	struct node *first = (struct node *) malloc (sizeof (struct node));
	first->data = b;
	first->prev = NULL;
	first->next = head;
	head->prev=first;
	head = first;

	break;

      }
    case 2:
      {
	printf ("enter a number to insert");
	scanf ("%d", &b);
	struct node *first = (struct node *) malloc (sizeof (struct node));
	temp->next = first;
	first->data = b;
	first->next = NULL;
	first->prev = temp;
	temp = first;
	break;

      }
    case 3:
      {
	printf ("enter a number to insert");
	scanf ("%d", &b);
	int count = 0;
	printf ("enter  position");
	scanf ("%d", &z);
	struct node *p1 = (struct node *) malloc (sizeof (struct node));
	p1 = head;
	struct node *first = (struct node *) malloc (sizeof (struct node));
	struct node *temp;
	while (p1 != NULL)
	  {
	    count++;
	    if (z == 1)
	      {
		first->data = b;
		first->prev = NULL;
		first->next = head;
		head = first;

		break;
	      }
	    else if (count == z)
	      {
		first->data = b;
		first->prev = p1->prev;
		first->next = p1;
		p1->prev->next = first;
		p1->prev = first;

		break;
	      }
	    p1 = p1->next;
	  }
	break;
      }
    case 4:
      {
	head = head->next;
	head->prev = NULL;
	break;
      }
    case 5:
      {
	temp->prev->next = NULL;
	temp = temp->prev;

	break;

      }
    case 6:
      {
	printf ("enter  position");
	scanf ("%d", &z);
	struct node *p1 = (struct node *) malloc (sizeof (struct node));
	p1 = head;
	int count = 0;
	while (p1 != NULL)
	  {
	    count++;
	    if (z == 1)
	      {
		head = head->next;
		head->prev = NULL;
		break;
	      }
	    else if (count == z)
	      {
		p1->next->prev = p1->prev;
		p1->prev->next = p1->next;
		break;
	      }
	    p1 = p1->next;
	  }



	break;
      }
    case 7:
      {
	printf ("total no of elements %d\n", count);
	break;

      }
    case 8:
      {

	struct node *ptr1 = (struct node *) malloc (sizeof (struct node));
	ptr1 = temp;
	while (ptr1 != NULL)
	  {

	    printf ("%d", ptr1->data);
	    ptr1 = ptr1->prev;

	  }
	break;
      }
    default:
      printf ("invalid input");
    }
  struct node *ptr1 = (struct node *) malloc (sizeof (struct node));
  ptr1 = head;
  while (ptr1 != NULL)
    {
      if (x == 7 || x == 8)
	{
	  break;

	}
      else
	{
	  printf ("%d", ptr1->data);
	  ptr1 = ptr1->next;
	}
    }

  return 0;
}
