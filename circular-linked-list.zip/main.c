/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.
Case1: Insertion at beginning

Case2: Insertion at End

Case 3:Insertion at Specific position

Case4: Deletion from beginning

Case5: Deletion from End

Case 6:Deletion from a specific position

Case7: Find the length of a linked list

Case 8: Reverse the Linked list

*******************************************************************************/
struct node{
    int data;
    struct node * link;
};
#include <stdio.h>
#include <stdlib.h>
int main()
{
    int n,i,a,z,x,count=0;
    printf("enter no of elements");
    scanf("%d",&n);
    struct node * head=NULL;
    struct node * temp=NULL;
    for(i=0;i<n;i++){
        scanf("%d",&a);
        struct node * first=(struct node *)malloc(sizeof(struct node));
        if(head==NULL){
            first->data=a;
            first->link=NULL;
            head=first;
            temp=first;
        }
        else{
            first->data=a;
            first->link=NULL;
            temp->link=first;
            temp=first;
        }
    }
    temp->link=head;
    
        printf("Case1: Insertion at beginning\nCase2: Insertion at End\nCase 3:Insertion at Specific position\nCase4: Deletion from beginning\nCase5: Deletion from End\nCase 6:Deletion from a specific position\nCase7: Find the length of a linked list\nCase 8: Reverse the Linked list");
        scanf("%d",&z);
        switch(z){
            //insertion at beginning
        case 1:{
            printf("enter a number to insert");
            scanf("%d",&a);
       struct node * first=(struct node *)malloc(sizeof(struct node));
        first->data=a;
        first->link=head;
        temp->link=first;
        head=first;
        break;
            
        }
        //insertion at end
        case 2:{
            printf("enter a number to insert");
            scanf("%d",&a);
       struct node * first=(struct node *)malloc(sizeof(struct node));
       first->data=a;
       first->link=head;
       temp->link=first;
       temp=first;
       break;
        }
        //insertion at specific position
        case 3:{
             printf("enter a number to insert");
            scanf("%d",&a);
            printf("enter  position to insert");
            scanf("%d",&x);
    	struct node *p1 = (struct node *) malloc (sizeof (struct node));
	    p1 = head;
       struct node * first=(struct node *)malloc(sizeof(struct node));
        while(p1!=NULL){
            count++;
            if(x==1){
            first->data=a;
            first->link=head;
            temp->link=first;
            head=first;
            break;
            }
            else if(count==x-1){
                first->data=a;
                first->link=p1->link;
                p1->link=first;
                break;
            }
             p1=p1->link;
        }
        break;
        }
        //deletion at beggining
        case 4:{
            head=head->link;
            temp->link=head;
             break;
        }
        //deletion at end
        case 5:{
    	    struct node *p1 = (struct node *) malloc (sizeof (struct node));
	         p1 = head;
	         count=0;
             while(count!=n){
            count++;
             if(count==n-1){
                 p1->link=head;
             }
                p1=p1->link;
            }
            break;
        }
        //deletion at specific position
        case 6:{
              printf("enter  position to delete");
            scanf("%d",&x);
             struct node *p1 = (struct node *) malloc (sizeof (struct node));
	         p1 = head;
            count=0;
            while(count!=n){
            count++;
            if(x==1){
             head=head->link;
            temp->link=head; 
                         break;

            }
            else if(count==x-1){
                p1->link=p1->link->link;
            }
            p1=p1->link;
        }
        break;
        }
        //count
        case 7:{
         struct node* ptr=head;
    do{
        count++;
        ptr=ptr->link;
    }while(ptr!=head);
          printf("totoal no of elements is :%d",count)  ;
          break;
        }
         // Reverse the Linked list
        case 8: {
            struct node* prev = NULL;
            struct node* current = head;
            struct node* next = NULL;

            do {
                next = current->link;
                current->link = prev;
                prev = current;
                current = next;
            } while (current != head);

            head->link = prev;
            head = prev;
            break;
        }
        }
        
    
            
        
 if(z==7){
     
 }
 else{
    struct node* ptr=head;
    do{
        printf("%d",ptr->data);
        ptr=ptr->link;
    }while(ptr!=head);
    //  while (ptr != NULL)
    // {
    //   printf ("%d\n", ptr->data);
    //   ptr = ptr->link;

    // }
}
    return 0;
}

